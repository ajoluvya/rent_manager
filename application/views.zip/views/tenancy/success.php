<div class="callout callout-success">
	<h4>Success!</h4>
	<p><?php echo $message; ?></p>
	<p>View <a href="<?php echo site_url('tenant'); ?>"> all tenants</a></p>
	<p>Add <a href="<?php echo site_url('tenant/create'); ?>"> new tenant</a></p>
</div>