<p>The user data was successfully submitted to the database</p>
<p><a href="<?php echo site_url('users/login'); ?>">Login now</a></p>