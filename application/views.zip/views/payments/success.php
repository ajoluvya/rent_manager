<div class="callout callout-success">
	<h4>Success!</h4>
	<p><?php echo $message; ?></p>
	<p>View <a href="<?php echo site_url('payment'); ?>">all payments data</a></p>
</div>