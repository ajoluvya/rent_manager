<div class="callout callout-warning">
	<h4>Search error!</h4>
	<p><?php echo $message; ?></p>
	<p>Go <a href="<?php echo site_url(substr(uri_string(),0,-2)); ?>">back</a></p>
</div>