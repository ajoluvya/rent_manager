<div class="callout callout-success">
	<h4>Success!</h4>
	<p><?php echo $message; ?></p>
	<p>View <a href="<?php echo site_url('estate'); ?>">all estates data</a></p>
</div>