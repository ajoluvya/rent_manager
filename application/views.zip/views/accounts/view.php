<div class="row">
	<div class="col-lg-6">
        <table class="table table-striped table-condensed table-hover">
                <tr><th>Account number</th><td><?php echo $account['acc_no']; ?></td></tr>
                <tr><th>Bank</th><td><?php echo $account['bank_name']; ?></td></tr>
                <tr><th>Notes</th><td><?php echo $account['acc_name']; ?></td></tr>
		</table>
	</div>
</div>